﻿using Microsoft.AspNetCore.Mvc;


namespace Quiz_Management.Controllers
{
    public class QuizController : Controller
    {
        private IConfiguration configuration;

        public QuizController(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
        public IActionResult QuizList()
        {
            return View();
        }
        public IActionResult QuizAdd()
        {
            return View();
        }
    }
}
