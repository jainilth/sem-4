﻿using System.Data;

namespace Quiz_Management.Models
{
    public class QuizModel
    {
        //public List<DataRow> Rows { get; set; } = new List<DataRow>();
        public string QuizName { get; set; }

        public int TotalQuestions { get; set; }

        public DateTime QuizDate { get; set; }

        public int UserId { get; set; }

    }
}
