﻿namespace newproject.Models
{
    public class AddProduct
    {
        public string PrName { get; set; }
        public string Price { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
    }
}
